EKEN H9 Firmware Upgrade.

Instructions:

ATTENTION: the camera only can be updated when the power is more than 50% or while charging.

1. Prepare a MicroSD card, and format it as FAT32. 

2. Copy the file "SPHOST.BRN" to the root of the card. 

3. Turn off the camera and insert the MicroSD card. 

4. Hold the power key until the camera turns on, the update process will begin (the screen will show: FW Update). It is done when the red light turns off.

5. Take the MicroSD card out, then start up the camera. 

6. For better results reset to factory settings.

Remember to remove the SPHOST.BRN file from the card or else the camera will burn the firmware again.